<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'GuestController@index');


Route::group(['prefix' => 'catalog'], function () {
    Route::get('/', 'Crud2Controller@index')->name('catalog');
    Route::match(['get', 'post'], 'create', 'Crud2Controller@create');
    Route::match(['get', 'put'], 'update/{id}', 'Crud2Controller@update')->middleware('admin');
    Route::delete('delete/{id}', 'Crud2Controller@delete')->middleware('admin');
});

Auth::routes();

Route::get('/dashboard', 'HomeController@index')->name('dashboard');

Route::group(['prefix' => 'admin-panel'], function() {

	Route::get('/', 'AdminController@index')->middleware('admin')->name('admin-panel');
	Route::get('getdata', 'AdminController@getdata')->name('admin-panel.getdata');

	Route::post('postdata', 'AdminController@postdata')->name('admin-panel.postdata');

	Route::get('fetchdata', 'AdminController@fetchdata')->name('admin-panel.fetchdata');
	Route::get('removedata', 'AdminController@removedata')->name('admin-panel.removedata');
});

Route::get('add-to-inventory/{id}', 'Crud2Controller@addToInventory');

Route::group(['prefix' => 'inventory'], function() {

	Route::get('/', 'Crud2Controller@inventory')->name('inventory');

	Route::get('getInventory', 'Crud2Controller@getInventory')->name('inventory.getInventory');
		 
	Route::get('removeInventory', 'Crud2Controller@removeInventory')->name('inventory.removeInventory');
});

Route::group(['prefix' => 'activity'], function() {

	Route::get('/', 'ActivityController@index')->middleware('admin')->name('activity');
	Route::get('getdata', 'ActivityController@getdata')->name('activity.getdata');
});