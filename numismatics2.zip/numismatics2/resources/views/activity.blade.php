@extends('layouts.app')

@section('css')
    <style>
        .columns {
            text-align: center;
            vertical-align: middle;
        </style>
@endsection

@section('content')

<div class="container">
    <br />
        <h3 align="center">User activity log</h3>
    <br />
        <table id="activities" class="table-bordered" style="width:100%">
            <thead align="center">
                <tr>
                    <th>ID</th>
                    <th>Log name</th>
                    <th>Description</th>
                    <th>Subject ID</th>
                    <th>Subject type</th>
                    <th>Causer ID</th>
                    <th>Causer type</th>
                    <th>Properties</th>
                    <th>Created at</th>
                    <th>Updated at</th>
                </tr>
            </thead>
        </table>
</div>

@endsection

@section('javascripts')
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
         $('#activities').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax": "{{ route('activity.getdata') }}",
            "columns":[
                { "data": "id", className:"columns" },
                { "data": "log_name", className:"columns" },
                { "data": "description", className:"columns" },
                { "data": "subject_id", className:"columns"},
                { "data": "subject_type", className:"columns" },
                { "data": "causer_id", className:"columns" },
                { "data": "causer_type", className:"columns" },
                { "data": "properties", className:"columns" },
                { "data": "created_at", className:"columns" },
                { "data": "updated_at", className:"columns" }
            ]
         });
    });
</script>
@endsection