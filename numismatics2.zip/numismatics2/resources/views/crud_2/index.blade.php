@extends('layouts.app')

@section('css')
    <style>
        a, a:hover {
            color: white;
        }
    </style>
@endsection

@section('content')
    <div class="container">
        <div class="float-right">
            @if(!Auth::check())
            @else
            <a href="{{url('catalog/create')}}" class="btn btn-primary">Add a new coin</a>
            @endif
        </div>
        <h1>Coin catalog</h1>
        <hr/>
        {!! Form::open(['method'=>'get']) !!}
        <div class="row">
            <div class="col-sm-4 form-group">
                
                {!! Form::select('Country', ['' => 'Select a country', 'Germany' => 'Germany', 'Lithuania' => 'Lithuania', 'Russia' => 'Russia'],null,['class'=>'form-control','onChange'=>'form.submit()']) !!}
                
            </div>
            <div class="col-sm-5 form-group">
                <div class="input-group">
                    <input class="form-control" id="search"
                           value="{{ request('search') }}"
                           placeholder="Search krause number" name="search"
                           type="text" id="search"/>
                    <div class="input-group-btn">
                        <button type="submit" class="btn btn-warning">
                            Search
                        </button>
                    </div>
                </div>
            </div>
            <input type="hidden" value="{{request('field')}}" name="field"/>
            <input type="hidden" value="{{request('sort')}}" name="sort"/>
        </div>
        {!! Form::close() !!}
        <table class="table-bordered">
            <thead class="bg-dark" style="color: white" align="center">
            <tr>
                <th>
                    <a>
                        Image
                    </a>
                </th>
                <th>
                    <a href="{{url('catalog')}}?search={{request('search')}}&Country={{request('Country')}}&field=Krause_number&sort={{request('sort','asc')=='asc'?'desc':'asc'}}">
                        Krause number
                    </a>
                    {!!request('field')=='Krause_number'?(request('sort','asc')=='asc'?'&#9652;':'&#9662;'):''!!}
                </th>
                <th>
                    <a href="{{url('catalog')}}?search={{request('search')}}&Country={{request('Country')}}&field=Country&sort={{request('sort','asc')=='asc'?'desc':'asc'}}">
                        Country
                    </a>
                    {!!request('field')=='Country'?(request('sort','asc')=='asc'?'&#9652;':'&#9662;'):''!!}
                </th>
                <th>
                    <a href="{{url('catalog')}}?search={{request('search')}}&Country={{request('Country')}}&field=Denomination&sort={{request('sort','asc')=='asc'?'desc':'asc'}}">
                        Denomination
                    </a>
                    {!!request('field')=='Denomination'?(request('sort','asc')=='asc'?'&#9652;':'&#9662;'):''!!}
                </th>
                <th>
                    <a href="{{url('catalog')}}?search={{request('search')}}&Country={{request('Country')}}&field=Year&sort={{request('sort','asc')=='asc'?'desc':'asc'}}">
                        Year
                    </a>
                    {!!request('field')=='Year'?(request('sort','asc')=='asc'?'&#9652;':'&#9662;'):''!!}
                </th>
                <th>
                    <a href="{{url('catalog')}}?search={{request('search')}}&Country={{request('Country')}}&field=Period&sort={{request('sort','asc')=='asc'?'desc':'asc'}}">
                        Period
                    </a>
                    {!!request('field')=='Period'?(request('sort','asc')=='asc'?'&#9652;':'&#9662;'):''!!}
                </th>
                <th>
                    <a href="{{url('catalog')}}?search={{request('search')}}&Country={{request('Country')}}&field=Coin_type&sort={{request('sort','asc')=='asc'?'desc':'asc'}}">
                        Coin type
                    </a>
                    {!!request('field')=='Coin_type'?(request('sort','asc')=='asc'?'&#9652;':'&#9662;'):''!!}
                </th>
                <th>
                    <a href="{{url('catalog')}}?search={{request('search')}}&Country={{request('Country')}}&field=Composition&sort={{request('sort','asc')=='asc'?'desc':'asc'}}">
                        Composition
                    </a>
                    {!!request('field')=='Composition'?(request('sort','asc')=='asc'?'&#9652;':'&#9662;'):''!!}
                </th>
                <th>
                    <a href="{{url('catalog')}}?search={{request('search')}}&Country={{request('Country')}}&field=Edge_type&sort={{request('sort','asc')=='asc'?'desc':'asc'}}">
                        Edge type
                    </a>
                    {!!request('field')=='Edge_type'?(request('sort','asc')=='asc'?'&#9652;':'&#9662;'):''!!}
                </th>
                <th>
                    <a href="{{url('catalog')}}?search={{request('search')}}&Country={{request('Country')}}&field=Shape&sort={{request('sort','asc')=='asc'?'desc':'asc'}}">
                        Shape
                    </a>
                    {!!request('field')=='Shape'?(request('sort','asc')=='asc'?'&#9652;':'&#9662;'):''!!}
                </th>
                <th>
                    <a href="{{url('catalog')}}?search={{request('search')}}&Country={{request('Country')}}&field=Alignment&sort={{request('sort','asc')=='asc'?'desc':'asc'}}">
                        Alignment
                    </a>
                    {!!request('field')=='Alignment'?(request('sort','asc')=='asc'?'&#9652;':'&#9662;'):''!!}
                </th>
                <th>
                    <a href="{{url('catalog')}}?search={{request('search')}}&Country={{request('Country')}}&field=Weight&sort={{request('sort','asc')=='asc'?'desc':'asc'}}">
                        Weight(gr)
                    </a>
                    {!!request('field')=='Weight'?(request('sort','asc')=='asc'?'&#9652;':'&#9662;'):''!!}
                </th>
                <th>
                    <a href="{{url('catalog')}}?search={{request('search')}}&Country={{request('Country')}}&field=Diameter&sort={{request('sort','asc')=='asc'?'desc':'asc'}}">
                        Diameter(mm)
                    </a>
                    {!!request('field')=='Diameter'?(request('sort','asc')=='asc'?'&#9652;':'&#9662;'):''!!}
                </th>
                <th>
                    <a href="{{url('catalog')}}?search={{request('search')}}&Country={{request('Country')}}&field=Thickness&sort={{request('sort','asc')=='asc'?'desc':'asc'}}">
                        Thickness(mm)
                    </a>
                    {!!request('field')=='Thickness'?(request('sort','asc')=='asc'?'&#9652;':'&#9662;'):''!!}
                </th>
                @if(!Auth::check())
                @else
                <th>Action</th>
                @endif
            </tr>
            </thead>
            <tbody>
            @foreach($catalogs as $catalog)
                <tr align="center">
                    <td>
                        <img src="{{ asset('uploads/images/' . $catalog->image) }}" width="100px" height="100px">
                    </td>
                    <td>{{$catalog->Krause_number}}</td>
                    <td>{{$catalog->Country}}</td>
                    <td>{{$catalog->Denomination}}</td>
                    <td>{{$catalog->Year}}</td>
                    <td>{{$catalog->Period}}</td>
                    <td>{{$catalog->Coin_type}}</td>
                    <td>{{$catalog->Composition}}</td>
                    <td>{{$catalog->Edge_type}}</td>
                    <td>{{$catalog->Shape}}</td>
                    <td>{{$catalog->Alignment}}</td>
                    <td>{{$catalog->Weight}}</td>
                    <td>{{$catalog->Diameter}}</td>
                    <td>{{$catalog->Thickness}}</td>
                    @if(!Auth::check() || auth()->user()->isAdmin != 1)
                    @else
                    <td align="center">
                        <form id="frm_{{$catalog->id}}" 
                            action="{{url('catalog/delete/'.$catalog->id)}}"
                            method="post" style="padding-bottom: 0px;margin-bottom: 0px">
                                <a class="btn btn-primary btn-sm" title="Edit"
                                    href="{{url('catalog/update/'.$catalog->id)}}">
                                    Edit
                                </a>
                            <input type="hidden" name="_method" value="delete"/>
                            {{csrf_field()}}
                                <a class="btn btn-danger btn-sm" title="Delete"
                                    href="javascript:if(confirm('Are you sure want to delete?')) $('#frm_{{$catalog->id}}').submit()">
                                    Delete
                                </a>
                                <p class="btn-holder"><a href="{{ url('add-to-inventory/'.$catalog->id) }}" class="btn btn-warning btn-block text-center" role="button">Add to collection</a> </p>
                        </form>
                    @endif
                    @if(Auth::check() && auth()->user()->isAdmin != 1)
                    <td align="center">
                        <form id="frm_{{$catalog->id}}" 
                            action="{{url('catalog/delete/'.$catalog->id)}}"
                            method="post" style="padding-bottom: 0px;margin-bottom: 0px">
                            <p class="btn-holder"><a href="{{ url('add-to-inventory/'.$catalog->id) }}" class="btn btn-warning btn-block text-center" role="button">Add to collection</a> </p>
                        </form>
                    @endif
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
        <nav>
            <ul class="pagination justify-content-end">
                {{$catalogs->links('vendor.pagination.bootstrap-4')}}
            </ul>
        </nav>
    </div>
@endsection