@extends('layouts.app')

@section('css')
    <style>
        .form-group.required label:after {
            content: " *";
            color: red;
            font-weight: bold;
        }
    </style>
@endsection

@section('content')
    <div class="container">
        <div class="col-md-8 offset-md-2">
            <h1>{{isset($catalog)?'Edit':'New'}} Coin</h1>
            <hr/>
            @if(isset($catalog))
                {!! Form::model($catalog,['method'=>'put', 'enctype' => 'multipart/form-data']) !!}
            @else
                {!! Form::open(['files' => 'true']) !!}
            @endif
            <div class="form-group row required">
                {!! Form::label("image","Image",["class"=>"col-form-label col-md-3 col-lg-2"]) !!}
                <div class="col-md-8">
                    {!! Form::file("image") !!}
                </div>
            </div>
            <div class="form-group row">
                {!! Form::label("Krause_number","Krause number",["class"=>"col-form-label col-md-3 col-lg-2"]) !!}
                <div class="col-md-8">
                    {!! Form::text("Krause_number",null,["class"=>"form-control".($errors->has('Krause_number')?" is-invalid":""),"autofocus",'placeholder'=>'Krause number']) !!}
                    {!! $errors->first('Krause_number','<span class="invalid-feedback">:message</span>') !!}
                </div>
            </div>
            <div class="form-group row required">
                {!! Form::label("Country","Country",["class"=>"col-form-label col-md-3 col-lg-2"]) !!}
                <div class="col-md-8">
                    {!! Form::text("Country",null,["class"=>"form-control".($errors->has('Country')?" is-invalid":""),"autofocus",'placeholder'=>'Country']) !!}
                    {!! $errors->first('Country','<span class="invalid-feedback">:message</span>') !!}
                </div>
            </div>
            <div class="form-group row required">
                {!! Form::label("Denomination","Denomination",["class"=>"col-form-label col-md-3 col-lg-2"]) !!}
                <div class="col-md-8">
                    {!! Form::text("Denomination",null,["class"=>"form-control".($errors->has('Denomination')?" is-invalid":""),'placeholder'=>'Denomination']) !!}
                    {!! $errors->first('Denomination','<span class="invalid-feedback">:message</span>') !!}
                </div>
            </div>
            <div class="form-group row required">
                {!! Form::label("Year","Year",["class"=>"col-form-label col-md-3 col-lg-2"]) !!}
                <div class="col-md-8">
                    {!! Form::number("Year",null,["class"=>"form-control".($errors->has('Year')?" is-invalid":""),'placeholder'=>'Year']) !!}
                    {!! $errors->first('Year','<span class="invalid-feedback">:message</span>') !!}
                </div>
            </div>
            <div class="form-group row">
                {!! Form::label("Period","Period",["class"=>"col-form-label col-md-3 col-lg-2"]) !!}
                <div class="col-md-8">
                    {!! Form::text("Period",null,["class"=>"form-control".($errors->has('Period')?" is-invalid":""),'placeholder'=>'Period']) !!}
                    {!! $errors->first('Period','<span class="invalid-feedback">:message</span>') !!}
                </div>
            </div>
            <div class="form-group row">
                {!! Form::label("Coin_type","Coin type",["class"=>"col-form-label col-md-3 col-lg-2"]) !!}
                <div class="col-md-8">
                    {!! Form::text("Coin_type",null,["class"=>"form-control".($errors->has('Coin_type')?" is-invalid":""),'placeholder'=>'Coin type']) !!}
                    {!! $errors->first('Coin_type','<span class="invalid-feedback">:message</span>') !!}
                </div>
            </div>
            <div class="form-group row">
                {!! Form::label("Composition","Composition",["class"=>"col-form-label col-md-3 col-lg-2"]) !!}
                <div class="col-md-8">
                    {!! Form::text("Composition",null,["class"=>"form-control".($errors->has('Composition')?" is-invalid":""),'placeholder'=>'Composition']) !!}
                    {!! $errors->first('Composition','<span class="invalid-feedback">:message</span>') !!}
                </div>
            </div>
            <div class="form-group row">
                {!! Form::label("Edge_type","Edge type",["class"=>"col-form-label col-md-3 col-lg-2"]) !!}
                <div class="col-md-8">
                    {!! Form::text("Edge_type",null,["class"=>"form-control".($errors->has('Edge_type')?" is-invalid":""),'placeholder'=>'Edge type']) !!}
                    {!! $errors->first('Edge_type','<span class="invalid-feedback">:message</span>') !!}
                </div>
            </div>
            <div class="form-group row">
                {!! Form::label("Shape","Shape",["class"=>"col-form-label col-md-3 col-lg-2"]) !!}
                <div class="col-md-8">
                    {!! Form::text("Shape",null,["class"=>"form-control".($errors->has('Shape')?" is-invalid":""),'placeholder'=>'Shape']) !!}
                    {!! $errors->first('Shape','<span class="invalid-feedback">:message</span>') !!}
                </div>
            </div>
            <div class="form-group row">
                {!! Form::label("Alignment","Alignment",["class"=>"col-form-label col-md-3 col-lg-2"]) !!}
                <div class="col-md-8">
                    {!! Form::text("Alignment",null,["class"=>"form-control".($errors->has('Alignment')?" is-invalid":""),'placeholder'=>'Alignment']) !!}
                    {!! $errors->first('Alignment','<span class="invalid-feedback">:message</span>') !!}
                </div>
            </div>
            <div class="form-group row">
                {!! Form::label("Weight","Weight",["class"=>"col-form-label col-md-3 col-lg-2"]) !!}
                <div class="col-md-8">
                    {!! Form::number("Weight",null,["class"=>"form-control".($errors->has('Weight')?" is-invalid":""),'placeholder'=>'Weight']) !!}
                    {!! $errors->first('Weight','<span class="invalid-feedback">:message</span>') !!}
                </div>
            </div>
            <div class="form-group row">
                {!! Form::label("Diameter","Diameter",["class"=>"col-form-label col-md-3 col-lg-2"]) !!}
                <div class="col-md-8">
                    {!! Form::number("Diameter",null,["class"=>"form-control".($errors->has('Diameter')?" is-invalid":""),'placeholder'=>'Diameter']) !!}
                    {!! $errors->first('Diameter','<span class="invalid-feedback">:message</span>') !!}
                </div>
            </div>
            <div class="form-group row">
                {!! Form::label("Thickness","Thickness",["class"=>"col-form-label col-md-3 col-lg-2"]) !!}
                <div class="col-md-8">
                    {!! Form::number("Thickness",null,["class"=>"form-control".($errors->has('Thickness')?" is-invalid":""),'placeholder'=>'Thickness']) !!}
                    {!! $errors->first('Thickness','<span class="invalid-feedback">:message</span>') !!}
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-3 col-lg-2"></div>
                <div class="col-md-4">
                    <a href="{{url('catalog')}}" class="btn btn-danger">
                        Back</a>
                    {!! Form::button("Save",["type" => "submit","class"=>"btn
                btn-primary"])!!}
                </div>
            </div>
            {!! Form::close() !!}
        </div>
    </div>
@endsection