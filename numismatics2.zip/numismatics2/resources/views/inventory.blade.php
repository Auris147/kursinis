@extends('layouts.app')
 
@section('css')
    <style>
        .columns {
            text-align: center;
            vertical-align: center;
        </style>
@endsection

@section('content')

    <div class="container">
    <br />
        <h3 align="center">My collection</h3>
    <br />
        <table id="inventories" class="table-bordered" style="width:100%">
            <thead align="center">
                <tr>
                    <th>Image</th>
                    <th>Country</th>
                    <th>Year</th>
                    <th>Denomination</th>
                    <th>Action</th>
                </tr>
            </thead>
        </table>
    </div>
@endsection

@section('javascripts')
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
         $('#inventories').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax": "{{ route('inventory.getInventory') }}",
            "columns":[
                { "data": "image", className:"columns", orderable:false, searchable: false,

                    "render": function (data, type, full, meta) {
                    return '<img src=/uploads/images/' + data + ' height="100px">';
                    },
                },
                { "data": "Country", className:"columns"},
                { "data": "Year", className:"columns" },
                { "data": "Denomination", className:"columns" },
                { "data": "action", className:"columns", orderable:false, searchable: false}
            ]
         });

        $(document).on('click', '.delete', function(){
            var id = $(this).attr('id');
            if(confirm("Are you sure you want to delete this coin?"))
            {
                $.ajax({
                    url:"{{route('inventory.removeInventory')}}",
                    mehtod:"get",
                    data:{id:id},
                    success:function(data)
                    {
                        alert(data);
                        $('#inventories').DataTable().ajax.reload();
                    }
                })
            }
            else
            {
                return false;
            }
        }); 

    });
</script>
@endsection