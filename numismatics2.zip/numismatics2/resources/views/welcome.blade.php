@extends('layouts.app')

@section('css')

	<style>
			


	</style>

@endsection

@section('content')

<div class="container" align="center">

    <h1>Welcome to our numismatics website.</h1>

    <div class="border">
    	<br>
        Check our announcements, chat with other users, discuss about coins in our forums.
        <br>
        <a href="{{url('forums')}}" class="btn btn-primary">Go to the forum</a>
        <hr>
        Browse our coin catalog, find your collected coins and add them to your collection.
        <br>
        <a href="{{url('catalog')}}" class="btn btn-primary">Go to the coin catalog</a>
        <hr>
        Search your collected coins.
        <br>
        <a href="{{url('inventory')}}" class="btn btn-primary">Go to my coin collection</a>
    	<br>
    	<br>
    </div>

</div>
@endsection