<?php

namespace App\Http\Controllers;

use Validator;
use Illuminate\Http\Request;
use App\User;
use DataTables;

class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    { 
        return view('admin');
    }

    function getdata()
    {
     $users = User::select('id', 'name', 'email');
     return Datatables::of($users)
            ->addColumn('action', function($user){
                return '<a href="#" class="btn btn-xs btn-primary edit" id="'.$user->id.'"><i class="glyphicon glyphicon-edit"></i> Edit</a><a href="#" class="btn btn-xs btn-danger delete" id="'.$user->id.'"><i class="glyphicon glyphicon-remove"></i> Delete</a>';
            })
            ->make(true);
    }

    function postdata(Request $request)
    {
        $error_array = array();
        $success_output = '';
        
        if($request->get('button_action') == 'insert')
        {
            $validationInsert = Validator::make($request->all(), [
                'name' => 'required',
                'password'  => 'required',
                'email'  => 'required',
            ]);

            if ($validationInsert->fails())
            {
                foreach($validationInsert->messages()->getMessages() as $field_name => $messages)
                {
                    $error_array[] = $messages;
                }
            }
            else
            {
                $user = new User([
                    'name'     =>  $request->get('name'),
                    'password'     =>  $request->get('password'),
                    'email'     =>  $request->get('email')
                ]);
                $user->save();
                $success_output = '<div class="alert alert-success">Data inserted</div>';
            }
        }
        if($request->get('button_action') == 'update')
        {
            $validationUpdate = Validator::make($request->all(), [
                'name' => 'required',
                'email'  => 'required',
            ]);

            if ($validationUpdate->fails())
            {
                foreach($validationUpdate->messages()->getMessages() as $field_name => $messages)
                {
                    $error_array[] = $messages;
                }
            }
            else
                {
                    $user = User::find($request->get('user_id'));
                    $user->name = $request->get('name');
                    $user->email = $request->get('email');
                    $user->save();
                    $success_output = '<div class="alert alert-success">Data updated</div>';
                }
        }

        $output = array(
            'error'     =>  $error_array,
            'success'   =>  $success_output
        );
        echo json_encode($output);
    }

    function fetchdata(Request $request)
    {
        $id = $request->input('id');
        $user = User::find($id);
        $output = array(
            'name'     =>  $user->name,
            'email'     =>  $user->email
        );
        echo json_encode($output);
    }

    function removedata(Request $request)
    {
        $user = User::find($request->input('id'));
        if($user->delete())
        {
            echo 'Data deleted';
        }
    }
}