<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Activity;
use DataTables;

class ActivityController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    { 
        return view('Activity');
    }

    function getdata()
    {
     $activities = Activity::select('id', 'log_name', 'description', 'subject_id', 'subject_type', 'causer_id', 'causer_type', 'properties', 'created_at', 'updated_at');
     return Datatables::of($activities)
            ->make(true);
    }
}