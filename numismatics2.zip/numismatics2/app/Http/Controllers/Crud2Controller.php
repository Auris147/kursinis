<?php
namespace App\Http\Controllers;

use App\Catalog;
use App\Inventory;
use Auth;
use DataTables;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;

class Crud2Controller extends Controller
{
    public function index(Request $request)
    {   
        $search = $request->get('search');
        $Country = $request->get('Country') != '' ? $request->get('Country') : -1;
        $field = $request->get('field') != '' ? $request->get('field') : 'Krause_number';
        $sort = $request->get('sort') != '' ? $request->get('sort') : 'asc';
        $catalogs = new Catalog();
        if ($Country != -1)
            $catalogs = $catalogs->where('Country', $Country);
            $catalogs = $catalogs->where('Krause_number', 'like', '%' . $search . '%')
            ->orderBy($field, $sort)
            ->paginate(5)
            ->withPath('?search=' . $search . '&Country=' . $Country . '&field=' . $field . '&sort=' . $sort);
        return view('crud_2.index', compact('catalogs'));
    }

    public function create(Request $request)
    {
        
        if ($request->isMethod('get'))
            return view('crud_2.form');
        else {
            $rules = [
                'image' => 'required',
                'Country' => 'required',
                'Denomination' => 'required',
                'Year' => 'required'
            ];
            $this->validate($request, $rules);
            $catalog = new Catalog();

            $file = request()->file('image');
            $filename = $file->getClientOriginalName();
            $destinationPath = 'uploads/images/';
            $uploadSuccess = $file->move($destinationPath, $filename);
            $catalog->image = $filename;
            
            $catalog->Krause_number = $request->Krause_number;
            $catalog->Country = $request->Country;
            $catalog->Denomination = $request->Denomination;
            $catalog->Year = $request->Year;
            $catalog->Period = $request->Period;
            $catalog->Coin_type = $request->Coin_type;
            $catalog->Composition = $request->Composition;
            $catalog->Edge_type = $request->Edge_type;
            $catalog->Shape = $request->Shape;
            $catalog->Alignment = $request->Alignment;
            $catalog->Weight = $request->Weight;
            $catalog->Diameter = $request->Diameter;
            $catalog->Thickness = $request->Thickness;
            $catalog->save();
            return redirect('/catalog');
        }
        
    }

    public function delete($id)
    {
        Catalog::destroy($id);
        return redirect('/catalog');
    }

    public function update(Request $request, $id)
    {
        if ($request->isMethod('get'))
            return view('crud_2.form', ['catalog' => Catalog::find($id)]);
        else {
            $rules = [
            ];

            $this->validate($request, $rules);
            $catalog = Catalog::find($id);
            
            $file = request()->file('image');
            $filename = $file->getClientOriginalName();
            $destinationPath = 'uploads/images/';
            $uploadSuccess = $file->move($destinationPath, $filename);
            $catalog->image = $filename;

            $catalog->Krause_number = $request->Krause_number;
            $catalog->Country = $request->Country;
            $catalog->Denomination = $request->Denomination;
            $catalog->Year = $request->Year;
            $catalog->Period = $request->Period;
            $catalog->Coin_type = $request->Coin_type;
            $catalog->Composition = $request->Composition;
            $catalog->Edge_type = $request->Edge_type;
            $catalog->Shape = $request->Shape;
            $catalog->Alignment = $request->Alignment;
            $catalog->Weight = $request->Weight;
            $catalog->Diameter = $request->Diameter;
            $catalog->Thickness = $request->Thickness;
            $catalog->save();
            return redirect('/catalog');
        }
    }

    public function inventory()
    { 
        if(Auth::user())
        {
            return view('inventory');
        }
        else
        {
            return redirect('login');
        }
    }

    public function addToInventory($id)
    {
        $coin = Catalog::find($id); //this will select the row with the given id

        //now save the data in the variables;
        $image = $coin->image;
        $Country = $coin->Country;
        $Year = $coin->Year;
        $Denomination = $coin->Denomination;
        
        $inventory = new Inventory();
        $inventory->image = $image;
        $inventory->Country = $Country;
        $inventory->Year = $Year;
        $inventory->Denomination = $Denomination;
        $inventory->user_id = Auth::id();
        $inventory->save();

        //then return to your view or whatever you want to do
        return redirect('catalog');

    }

    public function getInventory()
    {
        $inventories = Inventory::select('id', 'user_id', 'image', 'Country', 'Year', 'Denomination');
        return DataTables::of($inventories)
            ->filter(function($query)
            {
                $query->where('user_id', 'like', Auth::id());
            })
            ->addColumn('action', function($inventory){
                return '<a href="#" class="btn btn-xs btn-danger delete" id="'.$inventory->id.'"><i class="glyphicon glyphicon-remove"></i> Delete</a>';
            })
            ->make(true);
    }

    public function removeinventory(Request $request)
    {
        $inventory = Inventory::find($request->input('id'));
        if($inventory->delete())
        {
            echo 'Coin deleted';
        }
    }
}