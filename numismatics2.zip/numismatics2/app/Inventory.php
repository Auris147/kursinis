<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class Inventory extends Model
{
	use LogsActivity;

	public $timestamps = false;

	protected $table = 'inventories';

	protected $fillable = [
        'Country', 'Year', 'Denomination'
    ];
}